# calculator-app

Maven Java console project that imports `com.codegym:math-lib:1.0` from `lib/math-lib.jar` using the local system dependency specified in `pom.xml`.

## Build and run

1. Build `math-lib` with `mvn clean package`. Its JAR is `math-lib/target/math-lib-1.0.jar`.
2. Copy that JAR into `calculator-app/lib/` and name it `math-lib.jar` (a copy is already included here).
3. From this folder run `mvn clean package`.
4. Run the app. Linux/macOS:

```sh
java -cp "target/classes:lib/math-lib.jar" com.codegym.Main
```

On Windows, replace `:` with `;` in the classpath. Uncomment the `divide(10, 0)` line in `Main.java` to check the exception.
