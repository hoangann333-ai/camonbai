# math-lib

Maven Java library project (`com.codegym:math-lib:1.0`) containing the static `Calculator` methods. Build with `mvn clean package`; the standard Maven artifact is `target/math-lib-1.0.jar`.
