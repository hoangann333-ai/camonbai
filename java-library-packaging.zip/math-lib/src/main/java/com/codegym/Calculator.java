package com.codegym;

import java.security.NoSuchAlgorithmException;

/** Small static calculator utility packaged as a reusable JAR. */
public class Calculator {
    private Calculator() {
        // Utility class; do not instantiate.
    }

    public static int sum(int a, int b) {
        return a + b;
    }

    public static int sub(int a, int b) {
        return a - b;
    }

    public static int mul(int a, int b) {
        return a * b;
    }

    public static int divide(int a, int b) throws NoSuchAlgorithmException {
        if (b == 0) {
            throw new NoSuchAlgorithmException("Cannot divide by zero");
        }
        return a / b;
    }
}
